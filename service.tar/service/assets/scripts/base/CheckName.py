import KBEngine
from KBEDebug import *

class CheckName(KBEngine.Proxy):
	def __init__(self):
		KBEngine.Proxy.__init__(self)